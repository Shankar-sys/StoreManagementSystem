package com.cox.demo.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cox.demo.exception.RecordNotFoundException;
import com.cox.demo.model.StoreEntity;
import com.cox.demo.service.StoreService;

@RestController
@RequestMapping("/stores")
public class StoreController {
	@Autowired
	StoreService service;

	@GetMapping
	public ResponseEntity<List<StoreEntity>> getAllStores() {
		List<StoreEntity> list = service.getAllStores();
		return new ResponseEntity<List<StoreEntity>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<StoreEntity> getStoreById(@PathVariable("id") Long id) throws RecordNotFoundException {
		StoreEntity entity = service.getStoreById(id);

		return new ResponseEntity<StoreEntity>(entity, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/addStore")
	public ResponseEntity<StoreEntity> addStroe(@RequestBody StoreEntity Store) throws RecordNotFoundException {
		StoreEntity updated = service.createOrUpdateStore(Store);
		return new ResponseEntity<StoreEntity>(updated, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/updateStore")
	public ResponseEntity<StoreEntity> updateStore(@RequestBody StoreEntity Store) throws RecordNotFoundException {
		StoreEntity updated = service.createOrUpdateStore(Store);
		return new ResponseEntity<StoreEntity>(updated, new HttpHeaders(), HttpStatus.OK);
	}

	@DeleteMapping("/deleteStore/{id}")
	public HttpStatus deleteStoreById(@PathVariable("id") Long id) throws RecordNotFoundException {
		service.deleteStoreById(id);
		return HttpStatus.FORBIDDEN;
	}

}