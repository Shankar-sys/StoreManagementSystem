package com.cox.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cox.demo.exception.RecordNotFoundException;
import com.cox.demo.model.StoreEntity;
import com.cox.demo.repository.StoreRepository;
 
@Service
public class StoreService {
     
    @Autowired
    StoreRepository repository;
     
    public List<StoreEntity> getAllStores()
    {
        List<StoreEntity> StoreList = repository.findAll();
         
        if(StoreList.size() > 0) {
            return StoreList;
        } else {
            return new ArrayList<StoreEntity>();
        }
    }
     
    public StoreEntity getStoreById(Long id) throws RecordNotFoundException
    {
        Optional<StoreEntity> Store = repository.findById(id);
         
        if(Store.isPresent()) {
            return Store.get();
        } else {
            throw new RecordNotFoundException("No Store record exist for given id");
        }
    }
     
    public StoreEntity createOrUpdateStore(StoreEntity entity) throws RecordNotFoundException
    {
        Optional<StoreEntity> Store = repository.findById(entity.getId());
         
        if(Store.isPresent())
        {
            StoreEntity newEntity = Store.get();
            
            newEntity.setStoreName(entity.getStoreName());
            newEntity.setAddress(entity.getAddress());
            
            newEntity = repository.save(newEntity);
             
            return newEntity;
        } else {
            entity = repository.save(entity);
             
            return entity;
        }
    }
     
    public void deleteStoreById(Long id) throws RecordNotFoundException
    {
        Optional<StoreEntity> Store = repository.findById(id);
         
        if(Store.isPresent())
        {
            repository.deleteById(id);
        } else {
            throw new RecordNotFoundException("No Store record exist for given id");
        }
    }
}