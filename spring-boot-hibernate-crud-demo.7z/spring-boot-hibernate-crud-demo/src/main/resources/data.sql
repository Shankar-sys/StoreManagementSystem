INSERT INTO 
	STORE (store_name, address) 
VALUES
  	('Walmart', 'New Jersey'),
  	('Kroger', 'NewYor');